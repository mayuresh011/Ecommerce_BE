const {saveUser} = require('../database/user.js');
const CryptoJs = require('crypto-js');


const userService=async (username, email, password)=>{
    const newUser = {
        username,
         email,
         password : CryptoJs.AES.encrypt(password, process.env.PASS_SECURITY).toString()
    }

    const savedUser = await saveUser(newUser);
    return savedUser;
}

    module.exports = {userService}