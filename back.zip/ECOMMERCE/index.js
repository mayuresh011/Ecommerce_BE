const express = require('express');
const app = express();
const PORT = 3000;
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
const userRoutes = require('./routes/user.js');
const authRoute = require('./routes/auth.js')

app.use(express.json());
app.use(express.urlencoded());

app.use('/api/auth',authRoute);
app.use('/api/user',userRoutes);


mongoose.connect(process.env.MONGO_URL).then(()=>{
    console.log("connected to database");
}).catch((err)=>{
    console.log(err);
})

app.listen(PORT,()=>{
    console.log(`server started at ${PORT}`);
})