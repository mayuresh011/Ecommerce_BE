const userService = require('../services/createUser.js')
const User = require('../model/user.js');

const saveUser = async (user)=>{

    console.log("in a databse",user);
    const schema = new User(user);
    const savedUser = await schema.save(); // saving to database
   
    return savedUser;

}



module.exports = {saveUser};