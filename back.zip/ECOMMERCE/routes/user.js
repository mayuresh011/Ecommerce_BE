


// ------------------   THIS IS CREATED TO AUTH THE LOGIN PROCESS -------------

const router = require('express').Router();
const {registerUser} = require('../controller/registerController.js')

router.post("/register",registerUser);


module.exports = router; 