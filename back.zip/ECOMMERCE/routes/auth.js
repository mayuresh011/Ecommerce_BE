const router = require('express').Router();
const {userLogin} = require('../controller/userAuthController.js');


router.post("/login",userLogin);


module.exports = router;