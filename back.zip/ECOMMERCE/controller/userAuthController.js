const user = require("../model/user");
const cryptoJs = require('crypto-js');
const jwt = require('jsonwebtoken')



const userLogin = async(req,res,next)=>{

    const requestBody = req.body;

    //=================== CHECKING IF EMAIL IS PRESENT OR EMPTY ===========================
    try {
        const userInfo = await user.findOne({username : requestBody.username});
        if(!userInfo)
        {
            return res.json({
                ERROR : "Wrong username"
            });
        }

        const decryptedPassword = cryptoJs.AES.decrypt(userInfo.password,process.env.PASS_SECURITY);
        const finalPassword = decryptedPassword.toString(cryptoJs.enc.Utf8);

        if(finalPassword !== requestBody.password)
        {
            return res.json({
                ERROR : "Wrong credentials"
            });
        }

       
        const {password, ...others} = userInfo._doc; // used spread operator to hide password from the found data from DB to the postman window
        //And using ._doc bcuz data is saved into doc in mongo so we cant directly pass info have to define from where the data is coming
        
        //======================= TOKEN VALIDATION ===========================
       const accessToken = jwt.sign({
        id:userInfo._id,
        isAdmin : userInfo.isAdmin
       },process.env.JWT_SEC,{expiresIn:"10d"});
       
        res.json({
            LOGIN_DATA : others
        })

    } catch (error) {
        res.json({
            ERROR : error
        })
    }

    


}
module.exports={userLogin}