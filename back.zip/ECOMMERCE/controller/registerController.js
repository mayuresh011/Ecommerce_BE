
const { userService } = require('../services/createUser.js')


const registerUser = async (req, res, next) => {  // async is must
    
    const userName = req.body.username;
    const email = req.body.email;
    const password = req.body.password;

    const savedUser = await userService(userName, email, password);
    res.json(savedUser);
}

module.exports = { registerUser };